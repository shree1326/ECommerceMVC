﻿namespace eTickets.Data
{
    public enum PaintingCategory
    {
        Action = 1,
        Mandala,
        Drama,
        Madubani,
        Cartoon,
        Warli
    }
}
