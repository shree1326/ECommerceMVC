﻿using eTickets.Data.Base;
using eTickets.Models;

namespace eTickets.Data.Services
{
    public interface IOrganizersService:IEntityBaseRepository<Organizer>
    {
    }
}
